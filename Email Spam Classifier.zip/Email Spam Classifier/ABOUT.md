# NB1_EmailSpam
Created a Email Spam classfier using Naive Bayes Algorithm

Naive Bayes is a Machine learning algorithms , Which uses prior probability distribution on data to predict the target variable . Naive bayes is a 
generative algorithm.  

In this Project I have used two methods to predict for Email Spam ,
1 - > Binomial event model 
2 - > Multinomial event model

