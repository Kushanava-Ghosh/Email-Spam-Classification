Extract all the files from the zip into a single directory.

Run the python source file named "EmailSpam.py" in any suitable text editor or command prompt (Windows) and observe the results.
